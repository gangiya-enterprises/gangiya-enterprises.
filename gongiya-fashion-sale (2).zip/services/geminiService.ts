
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getStylingAdvice = async (prompt: string, imageBase64?: string) => {
  const model = 'gemini-3-flash-preview';
  
  const systemInstruction = `
    You are VogueAI, a world-class fashion stylist and trend expert.
    Your goal is to help users find the perfect outfit and provide fashion tips.
    Be encouraging, stylish, and informative.
    When users ask for suggestions, keep in mind current high-fashion trends and the importance of fit and color coordination.
    If an image is provided, analyze the user's outfit or the items shown and provide constructive feedback or styling pairings.
  `;

  try {
    const parts: any[] = [{ text: prompt }];
    
    if (imageBase64) {
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: imageBase64
        }
      });
    }

    const response = await ai.models.generateContent({
      model,
      contents: [{ parts }],
      config: {
        systemInstruction,
        temperature: 0.7,
        topP: 0.95,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to my fashion brain right now. Please try again later!";
  }
};
