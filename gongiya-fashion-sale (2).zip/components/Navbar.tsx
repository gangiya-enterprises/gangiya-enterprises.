
import React from 'react';
import { AppView } from '../types';

interface NavbarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  cartCount: number;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView, cartCount }) => {
  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 px-4 py-4 sm:px-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div 
          className="serif text-2xl font-bold tracking-tighter cursor-pointer"
          onClick={() => setView('home')}
        >
          VOGUE<span className="text-rose-500 underline decoration-2 underline-offset-4">AI</span>
        </div>
        
        <div className="hidden md:flex space-x-8 text-sm font-medium uppercase tracking-widest text-slate-600">
          <button 
            onClick={() => setView('home')}
            className={`hover:text-rose-500 transition-colors ${currentView === 'home' ? 'text-rose-500' : ''}`}
          >
            Home
          </button>
          <button 
            onClick={() => setView('shop')}
            className={`hover:text-rose-500 transition-colors ${currentView === 'shop' ? 'text-rose-500' : ''}`}
          >
            Shop
          </button>
          <button 
            onClick={() => setView('ai-stylist')}
            className={`hover:text-rose-500 transition-colors ${currentView === 'ai-stylist' ? 'text-rose-500' : ''}`}
          >
            AI Stylist
          </button>
        </div>

        <div className="flex items-center space-x-6">
          <button 
            className="relative p-2"
            onClick={() => setView('cart')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 1 0-7.5 0v4.5m11.356-1.993 1.112 16.826a2.25 2.25 0 0 1-2.244 2.399H4.282a2.25 2.25 0 0 1-2.244-2.399L3.15 8.507a2.25 2.25 0 0 1 2.244-2.206h12.24c1.059 0 1.97.75 2.146 1.794Z" />
            </svg>
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full flex items-center justify-center min-w-[18px]">
                {cartCount}
              </span>
            )}
          </button>
          <button className="md:hidden">
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
            </svg>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
