
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  return (
    <div className="group relative flex flex-col">
      <div className="relative aspect-[3/4] overflow-hidden bg-slate-100 rounded-lg">
        <img 
          src={product.image} 
          alt={product.name}
          className="h-full w-full object-cover object-center group-hover:scale-110 transition-transform duration-700"
        />
        {product.tag && (
          <span className="absolute top-3 left-3 bg-white px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-900 shadow-sm rounded">
            {product.tag}
          </span>
        )}
        <div className="absolute top-3 right-3 bg-rose-500 text-white px-2 py-1 text-[10px] font-bold rounded shadow-sm">
          -{discount}%
        </div>
        <button 
          onClick={() => onAddToCart(product)}
          className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur text-slate-900 py-3 text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0 rounded-md"
        >
          Add to Cart
        </button>
      </div>
      <div className="mt-4 flex flex-col">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-sm font-medium text-slate-900">{product.name}</h3>
            <p className="mt-1 text-xs text-slate-500">{product.category}</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-bold text-slate-900">${product.price}</p>
            <p className="text-xs text-slate-400 line-through">${product.originalPrice}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
