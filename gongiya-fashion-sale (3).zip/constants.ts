
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Silk Evening Gown',
    category: 'Women',
    price: 129,
    originalPrice: 250,
    image: 'https://picsum.photos/seed/dress1/600/800',
    description: 'Elegant floor-length silk gown with a tailored fit.',
    tag: 'Trending'
  },
  {
    id: '2',
    name: 'Casual Linen Blazer',
    category: 'Men',
    price: 89,
    originalPrice: 160,
    image: 'https://picsum.photos/seed/blazer1/600/800',
    description: 'Breathable linen blend blazer perfect for summer events.',
    tag: 'Best Seller'
  },
  {
    id: '3',
    name: 'Urban Leather Jacket',
    category: 'Men',
    price: 199,
    originalPrice: 350,
    image: 'https://picsum.photos/seed/jacket1/600/800',
    description: 'Classic biker-style genuine leather jacket.',
    tag: 'Limited'
  },
  {
    id: '4',
    name: 'Velvet Mini Skirt',
    category: 'Women',
    price: 45,
    originalPrice: 85,
    image: 'https://picsum.photos/seed/skirt1/600/800',
    description: 'Chic velvet skirt with high-waist detailing.',
    tag: 'Sale'
  },
  {
    id: '5',
    name: 'Cashmere Oversized Sweater',
    category: 'Women',
    price: 110,
    originalPrice: 220,
    image: 'https://picsum.photos/seed/sweater1/600/800',
    description: 'Luxuriously soft cashmere sweater for cozy days.',
    tag: 'New'
  },
  {
    id: '6',
    name: 'Slim Fit Chinos',
    category: 'Men',
    price: 55,
    originalPrice: 95,
    image: 'https://picsum.photos/seed/chinos1/600/800',
    description: 'Versatile cotton chinos for business casual looks.',
    tag: 'Essential'
  }
];

export const CATEGORIES = ['All', 'Men', 'Women', 'Sale'];
