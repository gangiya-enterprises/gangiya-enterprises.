
export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  image: string;
  description: string;
  tag?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type AppView = 'home' | 'shop' | 'cart' | 'ai-stylist';

export interface StylistMessage {
  role: 'user' | 'assistant';
  content: string;
  image?: string;
}
